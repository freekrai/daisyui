import{a as t}from"../chunks/entry.FwQcOg3S.js";export{t as start};
